package test2;


/**
 * 
 * @author 王浩
 * @date 2020年4月16日
 *
 */
public class Test2 {
	public static void main(String[] args) {
		Thread t1 = new Thread() {
			public void run() {
				test3.dosome();
			}
		};
		Thread t2 = new Thread() {
			public void run() {
				test3.dosome();
			}
		};
		t1.start();
		t2.start();
	}

}
class test3{
	public static void dosome() {
		synchronized (test3.class) {
			try {
				Thread t = Thread.currentThread();
				System.out.println(t.getName()+"：在客厅看电视");
				Thread.sleep(5000);
				synchronized (this) {
					System.out.println(t.getName()+"上厕所");
					Thread.sleep(5000);
				}
			} catch (Exception e) {
			}
		}
	}
}
