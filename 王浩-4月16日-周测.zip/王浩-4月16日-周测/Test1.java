package test2;

/**
 * @author 王浩
 * @date 2020年4月16日
 *
 */
public class Test1 {
	public static void main(String[] args) {
		Thread thread1 = new Thread() {
			public void run() {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					
				}
				System.out.println("前台线程结束");
			}	

			
		};
		Thread thread2 = new Thread() {
			public void run() {
				for(int i=0;i<5;i++) {
					System.out.println("两秒");
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						
					}
				}
				thread1.interrupt();
				System.out.println("计时线程结束");
			}	
		};
		thread1.start();
		thread2.start();
	}
}
